<?php
define("HOST_DB", 'localhost');
define("USER_DB", 'root');
define("PASS_DB", '');
define("DB", 'bookstore');

define ('ROOT', dirname(__FILE__));
define('BASE_URL', 'http://mvc.local/MVC3');
define('UPLOAD_IMG', ROOT .'/images/book');

